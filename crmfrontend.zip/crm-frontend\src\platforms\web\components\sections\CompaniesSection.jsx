import { useState, useEffect } from 'react';
import { Building2, Search, UserCheck, UserX, Edit, Eye } from 'lucide-react';
import ThreeDotMenu from '../common/ThreeDotMenu';
import { motion } from 'framer-motion';
import { useCompany } from '../../../../core/hooks/useCompany';
import { useAuth } from '../../../../shared/contexts/AuthContext';

import UpdateCompanyModal from '../modals/UpdateCompanyModal';
import ViewCompanyModal from '../modals/ViewCompanyModal';

const CompaniesSection = () => {
    const { user } = useAuth();
    const { companies, loading, loadAllCompanies, revokeCompany, unrevokeCompany } = useCompany();
    const [search, setSearch] = useState('');

    const [selectedCompany, setSelectedCompany] = useState(null);
    const [showUpdateModal, setShowUpdateModal] = useState(false);
    const [showViewModal, setShowViewModal] = useState(false);

    useEffect(() => {
        if (user?.role === 'DEVELOPER') {
            loadAllCompanies();
        }
    }, [user?.role, loadAllCompanies]);

    const handleSearch = (e) => setSearch(e.target.value.toLowerCase());

    const displayedCompanies = companies.filter((company) => {
        const fields = [company.name, company.email, company.phone];
        return fields.some((field) => field?.toString().toLowerCase().includes(search));
    });

    const handleToggleStatus = async (companyId, isActive) => {
        try {
            if (isActive) {
                await revokeCompany(companyId);
            } else {
                await unrevokeCompany(companyId);
            }
            await loadAllCompanies(); // Refresh the list
        } catch (error) {
            console.error('Error toggling company status:', error);
        }
    };

    const handleViewCompany = (company) => {
        setSelectedCompany(company);
        setShowViewModal(true);
    };

    const handleEditCompany = (company) => {
        setSelectedCompany(company);
        setShowUpdateModal(true);
    };



    const handleUpdateSuccess = () => {
        setShowUpdateModal(false);
        setSelectedCompany(null);
        loadAllCompanies();
    };

    if (user?.role !== 'DEVELOPER') {
        return (
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                <div className="text-center text-gray-500">
                    <Building2 size={48} className="mx-auto mb-4 text-gray-300" />
                    <p>You don't have permission to view companies.</p>
                </div>
            </div>
        );
    }

    return (
        <>
            {/* Update Company Modal */}
            <UpdateCompanyModal
                isOpen={showUpdateModal}
                onClose={() => {
                    setShowUpdateModal(false);
                    setSelectedCompany(null);
                }}
                company={selectedCompany}
                onUpdate={handleUpdateSuccess}
            />

            {/* View Company Modal */}
            <ViewCompanyModal
                isOpen={showViewModal}
                onClose={() => {
                    setShowViewModal(false);
                    setSelectedCompany(null);
                }}
                company={selectedCompany}
            />

            <motion.div
                className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden"
                initial={{ opacity: 0, y: -50 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, type: 'spring' }}
            >
                {/* Header */}
                <div className="sticky top-0 z-10 bg-white border-b border-gray-100 shadow-sm">
                    <div className="flex items-center justify-between mb-4">
                        <div className="flex items-center gap-3">
                            <Building2 className="text-gray-500" size={32} />
                            <span className="text-sm text-gray-500">({displayedCompanies.length} companies)</span>
                        </div>
                    </div>

                    <div className="flex items-center gap-4">
                        <div className="relative flex-1 max-w-md">
                            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
                            <input
                                type="text"
                                placeholder="Search companies..."
                                value={search}
                                onChange={handleSearch}
                                className="pl-10 pr-4 py-2 border border-gray-300 rounded-lg w-full focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                            />
                        </div>
                    </div>
                </div>

                {/* Content */}
                <div>
                    {loading ? (
                        <div className="space-y-4">
                            {[...Array(5)].map((_, i) => (
                                <div key={i} className="animate-pulse bg-white p-4 rounded-xl shadow border border-gray-200 space-y-3">
                                    <div className="h-4 bg-gray-300 rounded w-1/3"></div>
                                    <div className="h-4 bg-gray-300 rounded w-1/2"></div>
                                    <div className="h-3 bg-gray-200 rounded w-full"></div>
                                    <div className="h-3 bg-gray-200 rounded w-5/6"></div>
                                </div>
                            ))}
                        </div>
                    ) : (
                        <>
                            {/* Desktop Table View */}
                            <div className="hidden md:block max-h-[350px] overflow-y-auto rounded-lg border border-gray-200 shadow-sm">
                                <table className="min-w-full table-auto border-collapse bg-white">
                                    <thead className="bg-gradient-to-r from-blue-50 to-indigo-50 text-sm text-gray-800 sticky top-0 z-10">
                                        <tr>
                                            <th className="border-b px-6 py-4 text-left font-semibold">Company Name</th>
                                            <th className="border-b px-6 py-4 text-left font-semibold">Email</th>
                                            <th className="border-b px-6 py-4 text-left font-semibold">Phone</th>
                                            <th className="border-b px-6 py-4 text-left font-semibold">Max Users</th>
                                            <th className="border-b px-6 py-4 text-left font-semibold">Max Admins</th>
                                            <th className="border-b px-6 py-4 text-left font-semibold">Status</th>
                                            <th className="border-b px-6 py-4 text-center font-semibold">Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {displayedCompanies.length === 0 ? (
                                            <tr>
                                                <td colSpan="7" className="text-center py-8 text-gray-500">
                                                    <Building2 size={48} className="mx-auto mb-4 text-gray-300" />
                                                    <p>No companies found.</p>
                                                </td>
                                            </tr>
                                        ) : (
                                            displayedCompanies.map((company) => (
                                                <tr key={company.id} className="hover:bg-gray-50 transition-colors">
                                                    <td className="border-b px-6 py-4">
                                                        <div className="font-medium text-gray-900">{company.name}</div>
                                                    </td>
                                                    <td className="border-b px-6 py-4 text-gray-600">{company.email}</td>
                                                    <td className="border-b px-6 py-4 text-gray-600">{company.phone}</td>
                                                    <td className="border-b px-6 py-4 text-gray-600">{company.maxUsers || 'N/A'}</td>
                                                    <td className="border-b px-6 py-4 text-gray-600">{company.maxAdmins || 'N/A'}</td>
                                                    <td className="border-b px-6 py-4">
                                                        <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${company.status === 'active'
                                                            ? 'bg-green-100 text-green-800'
                                                            : 'bg-red-100 text-red-800'
                                                            }`}>
                                                            {company.status === 'active' ? 'Active' : 'Inactive'}
                                                        </span>
                                                    </td>
                                                    <td className="border-b px-2 py-2 text-center">
                                                        <ThreeDotMenu
                                                            item={company}
                                                            actions={[
                                                                {
                                                                    label: 'View Details',
                                                                    icon: <Eye size={14} />,
                                                                    onClick: () => handleViewCompany(company)
                                                                },
                                                                {
                                                                    label: 'Edit Company',
                                                                    icon: <Edit size={14} />,
                                                                    onClick: () => handleEditCompany(company)
                                                                },
                                                                company.status === 'active'
                                                                    ? {
                                                                        label: 'Deactivate Company',
                                                                        icon: <UserX size={14} />,
                                                                        onClick: () => handleToggleStatus(company.id, true),
                                                                        danger: true
                                                                    }
                                                                    : {
                                                                        label: 'Activate Company',
                                                                        icon: <UserCheck size={14} />,
                                                                        onClick: () => handleToggleStatus(company.id, false)
                                                                    },
                                                            ]}
                                                        />
                                                    </td>
                                                </tr>
                                            ))
                                        )}
                                    </tbody>
                                </table>
                            </div>

                            {/* Mobile Card View */}
                            <div className="space-y-4 md:hidden">
                                {displayedCompanies.length === 0 ? (
                                    <div className="text-center py-8 text-gray-500">
                                        <Building2 size={48} className="mx-auto mb-4 text-gray-300" />
                                        <p>No companies found.</p>
                                    </div>
                                ) : (
                                    displayedCompanies.map((company) => (
                                        <div
                                            key={company.id}
                                            className="bg-white border border-gray-200 rounded-xl p-6 shadow-sm hover:shadow-md transition-shadow duration-200"
                                        >
                                            <div className="flex justify-between items-start mb-3">
                                                <div className="font-semibold text-lg text-gray-800">
                                                    {company.name}
                                                </div>
                                                <ThreeDotMenu
                                                    item={company}
                                                    actions={[
                                                        {
                                                            label: 'View Details',
                                                            icon: <Eye size={14} />,
                                                            onClick: () => handleViewCompany(company)
                                                        },
                                                        {
                                                            label: 'Edit Company',
                                                            icon: <Edit size={14} />,
                                                            onClick: () => handleEditCompany(company)
                                                        },
                                                        company.status === 'active'
                                                            ? {
                                                                label: 'Deactivate Company',
                                                                icon: <UserX size={14} />,
                                                                onClick: () => handleToggleStatus(company.id, true),
                                                                danger: true
                                                            }
                                                            : {
                                                                label: 'Activate Company',
                                                                icon: <UserCheck size={14} />,
                                                                onClick: () => handleToggleStatus(company.id, false)
                                                            },
                                                    ]}
                                                />
                                            </div>
                                            <div className="space-y-2 text-sm">
                                                <div className="flex items-center">
                                                    <span className="font-medium text-gray-500 w-24">Email:</span>
                                                    <span className="text-gray-700">{company.email}</span>
                                                </div>
                                                <div className="flex items-center">
                                                    <span className="font-medium text-gray-500 w-24">Phone:</span>
                                                    <span className="text-gray-700">{company.phone}</span>
                                                </div>
                                                <div className="flex items-center">
                                                    <span className="font-medium text-gray-500 w-24">Max Users:</span>
                                                    <span className="text-gray-700">{company.maxUsers || 'N/A'}</span>
                                                </div>
                                                <div className="flex items-center">
                                                    <span className="font-medium text-gray-500 w-24">Max Admins:</span>
                                                    <span className="text-gray-700">{company.maxAdmins || 'N/A'}</span>
                                                </div>
                                                <div className="flex items-center">
                                                    <span className="font-medium text-gray-500 w-24">Status:</span>
                                                    <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${
                                                        company.status === 'active'
                                                            ? 'bg-green-100 text-green-800'
                                                            : 'bg-red-100 text-red-800'
                                                    }`}>
                                                        {company.status === 'active' ? 'Active' : 'Inactive'}
                                                    </span>
                                                </div>
                                            </div>
                                        </div>
                                    ))
                                )}
                            </div>
                        </>
                    )}
                </div>
            </motion.div>
        </>
    );
};

export default CompaniesSection;