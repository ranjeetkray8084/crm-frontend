import { useState, useMemo } from 'react';
import PropertyTableRow from './PropertyTableRow';
import { ArrowUp, ArrowDown } from 'lucide-react';

const PropertiesTable = ({ properties, onDelete, onAddRemark, onViewRemarks, onUpdate, onStatusChange, onOutOfBox, onShowReminderModal, companyId, onShowPropertyCodeModal }) => {
  const [sortConfig, setSortConfig] = useState({ key: 'createdAt', direction: 'desc' });

  const handleSort = (key) => {
    let direction = 'asc';
    if (sortConfig.key === key && sortConfig.direction === 'asc') {
      direction = 'desc';
    }
    setSortConfig({ key, direction });
  };

  const sortedProperties = useMemo(() => {
    if (!sortConfig.key) return properties;

    return [...properties].sort((a, b) => {
      const getNestedValue = (obj, path) => path.split('.').reduce((o, i) => (o ? o[i] : null), obj);
      const aValue = getNestedValue(a, sortConfig.key);
      const bValue = getNestedValue(b, sortConfig.key);

      if (aValue === null || aValue === undefined) return 1;
      if (bValue === null || bValue === undefined) return -1;

      if (aValue < bValue) return sortConfig.direction === 'asc' ? -1 : 1;
      if (aValue > bValue) return sortConfig.direction === 'asc' ? 1 : -1;
      return 0;
    });
  }, [properties, sortConfig]);

  const getSortIcon = (columnKey) => {
    if (sortConfig.key !== columnKey) return null;
    return sortConfig.direction === 'asc'
      ? <ArrowUp className="h-4 w-4 ml-1 inline" />
      : <ArrowDown className="h-4 w-4 ml-1 inline" />;
  };

  const SortableHeader = ({ columnKey, title, className = "" }) => (
    <th
      className={`px-3 py-3 text-left text-xs font-bold text-gray-900 uppercase tracking-wider cursor-pointer hover:bg-gray-100 whitespace-nowrap ${className}`}
      onClick={() => handleSort(columnKey)}
    >
      {title}
      {getSortIcon(columnKey)}
    </th>
  );

  return (
    <div className="hidden md:block overflow-x-auto max-h-[60vh] overflow-y-auto border border-gray-200 rounded-lg">
      <table className="min-w-[1200px] w-full table-auto text-sm text-left text-gray-700">
        <thead className="bg-gray-50 sticky top-0 z-10">
          <tr>
            <SortableHeader className='text-center' columnKey="propertyName" title="Project Name" />
            <SortableHeader className='text-center' columnKey="status" title="Status" />
            <SortableHeader className='text-center' columnKey="type" title="Type" />
            <SortableHeader className='text-center' columnKey="price" title="Price" />
            <SortableHeader className='text-center' columnKey="bhk" title="BHK" />
            <SortableHeader className='text-center' columnKey="size" title="Size" />
            <SortableHeader className='text-center' columnKey="unitDetails" title="Unit" />
            <SortableHeader className='text-center' columnKey="floor" title="Floor" />
            <SortableHeader className='text-center' columnKey="ownerName" title="Owner/Broker" />
            <SortableHeader className='text-center' columnKey="ownerNumber" title="Owner No." />
            <SortableHeader className='text-center' columnKey="sector" title="Sector" />
            <SortableHeader className='text-center' columnKey="location" title="Location" />
            <SortableHeader className='text-center' columnKey="createdAt" title="Created" />
            <th className="px-3 py-3 text-left text-xs font-bold text-gray-500 uppercase tracking-wider whitespace-nowrap">
              Actions
            </th>
          </tr>
        </thead>
        <tbody className="bg-white divide-y divide-gray-200">
          {sortedProperties.map((property) => (
            <PropertyTableRow
              key={property.propertyId || property.id}
              property={property}
              onAddRemark={onAddRemark}
              onViewRemarks={onViewRemarks}
              onUpdate={onUpdate}
              onStatusChange={onStatusChange}
              onOutOfBox={onOutOfBox}
              onShowReminderModal={onShowReminderModal}
              companyId={companyId}
              onShowPropertyCodeModal={onShowPropertyCodeModal}
            />
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default PropertiesTable;
